import React from "react";

function Note(props) {
  return (
    <div className="note border">
      <h1 className="note-title">{props.title}</h1>
      <p className="note-content">{props.content}</p>
    </div>
  );
}

export default Note;
